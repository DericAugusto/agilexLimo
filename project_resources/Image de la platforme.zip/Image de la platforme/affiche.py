import matplotlib.pyplot as plt
import matplotlib.image as mpimg

img = mpimg.imread("plateformecoloriee.png")
imgplot = plt.imshow(img)
plt.show()